import React, { Component } from "react";

class Header extends Component {
  render() {
    return (
      <div className="text-center">
        <h1>
        Calculator for prime numbers!!
        </h1>
      <hr />
      </div>      
      // <div className="text-center">
    );
  }
}

export default Header;