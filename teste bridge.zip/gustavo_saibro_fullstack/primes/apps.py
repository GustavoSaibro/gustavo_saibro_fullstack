from django.apps import AppConfig


class PrimesConfig(AppConfig):
    name = 'primes'
